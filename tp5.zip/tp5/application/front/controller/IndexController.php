<?php
namespace app\front\controller;

use think\Controller;

class IndexController extends Controller
{
    public function index()

    {

        return $this->fetch();
    }
    //显示新闻页面

    public function news()
    {
        return $this->fetch();
    }

    public function author()
    {
        return $this->fetch();
    }
   
}
