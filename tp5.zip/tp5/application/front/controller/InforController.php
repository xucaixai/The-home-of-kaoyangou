<?php
namespace app\front\controller;

use think\Controller;

class InforController extends Controller
{
    //显示专业页面

    public function major()
    {
        return $this->fetch();
    }
    //显示学校界面

    public function school()
    {
        return $this->fetch();
    }
    //显示详细学校页面
    public function sinfo()
    {
        return $this->fetch();
    }
   
}
