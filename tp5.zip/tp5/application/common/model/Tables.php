<?php
namespace app\common\model;

use think\Model;
use traits\model\SoftDelete;

class Tables extends Model
{
    use SoftDelete;
}
