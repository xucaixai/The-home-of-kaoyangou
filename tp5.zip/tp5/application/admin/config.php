<?php

return[
	'host'=>'http://ljyu.wywwwxm.com/tp5/public/index.php',
	'oauth_stepl'=>'/admin/Oauth/OauthCode',
];
?>