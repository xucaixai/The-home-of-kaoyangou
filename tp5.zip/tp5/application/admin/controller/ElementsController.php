<?php

namespace app\admin\controller;
use app\common\model\Elements;
use think\Controller;
use think\Request;

class ElementsController extends Controller
{
    public function index()
    {
         // 从模型中读取数据
        $indexs = Elements::all();
        // 把数据赋值给视图
        $this->assign('indexs', $indexs);
        // 显示视图
        return $this->fetch();
    }
}
