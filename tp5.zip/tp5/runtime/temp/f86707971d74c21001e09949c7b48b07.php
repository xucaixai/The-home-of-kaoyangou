<?php if (!defined('THINK_PATH')) exit(); /*a:2:{s:67:"D:\phpStudy\WWW\tp5\public/../application/home\view\user\index.html";i:1512390849;s:63:"D:\phpStudy\WWW\tp5\public/../application/home\view\layout.html";i:1512390897;}*/ ?>
<!DOCTYPE html>
<html lang="zh-CN">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- 上述3个meta标签*必须*放在最前面，任何其他内容都*必须*跟随其后！ -->
    <title>软件/硬件产品内容发布与产品服务系统</title>

    <!-- Bootstrap -->
    <link href="/static/css/bootstrap.min.css" rel="stylesheet">


</head>

<body>
    <nav class="navbar navbar-default">
        <div class="container-fluid">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="#">Brand</a>
            </div>

            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav">
                    <?php if(is_array() ||  instanceof \think\Collection ||  instanceof \think\Paginator): $i = 0; $__LIST__ = ;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
                    <li>
                        <a href="<?php echo $vo['path']; ?>">
                            <?php echo $vo['name']; ?>
                        </a>
                    </li>
                    <?php endforeach; endif; else: echo "" ;endif; ?>
                </ul>

                <ul class="nav navbar-nav navbar-right">
                    <?php if(empty(\think\Session::get('loginedUser')) || ((\think\Session::get('loginedUser') instanceof \think\Collection || \think\Session::get('loginedUser') instanceof \think\Paginator ) && \think\Session::get('loginedUser')->isEmpty())): ?>
                    <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
                            登录/帮助
                            <span class="caret"></span>
                        </a>
                        <ul class="dropdown-menu">
                            <li><a href="/home">登录</a></li>
                            <li role="separator" class="divider"></li>
                            <li><a href="http://www.baidu.com">帮助</a></li>
                        </ul>
                    </li>
                    <?php else: ?>
                    <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
                            <?php echo \think\Session::get('loginedUser'); ?>
                            <span class="caret"></span>
                        </a>
                        <ul class="dropdown-menu">
                            <li><a href="/index/user/index">个人中心</a></li>
                            <li role="separator" class="divider"></li>
                            <li><a href="/index">注销</a></li>
                        </ul>
                    </li>
                    <?php endif; ?>
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container-fluid -->
    </nav>

    <div class="container">
        <div class="panel panel-default">
    <div class="panel-heading">
        <h3 class="panel-title">管理员登录</h3>
    </div>
    <div class="panel-body">
        <form action="admin/" method="post" class="form-horizontal">
            <div class="form-group">
                <label class="col-sm-2 control-label">用户名</label>
                <div class="col-sm-5">
                    <input type="text" class="form-control" id="admin" placeholder="用户名">
                </div>
            </div>
            <div class="form-group">
                <label class="col-sm-2 control-label">密码</label>
                <div class="col-sm-5">
                    <input type="password" class="form-control" id="password" placeholder="密码">
                </div>
            </div>
            <div class="form-group">
                <label class="col-sm-2 control-label">验证码</label>
                <div class="col-sm-5">
                    <input type="text" class="form-control" name="captcha"><br/>
                <!--:captcha_img('login')-->
                    <img src="<?php echo captcha_src('login'); ?>" onclick="changeCaptcha(this)">
                </div>
            </div>
            <div class="col-sm-offset-6 col-sm-10">
                <input type="submit" class="btn btn-default" value="登录">
            </div>
        </form>
    </div>
</div>

<script>
    function changeCaptcha(obj)
    {
        // 单击以后，修改图片的src属性
        $(obj).attr('src', "<?php echo captcha_src('login'); ?>?"+Math.random());
    }
</script>
    </div>



    <script src="https://cdn.bootcss.com/jquery/1.12.4/jquery.min.js"></script>
    <script src="/static/js/bootstrap.min.js"></script>
</body>

</html>