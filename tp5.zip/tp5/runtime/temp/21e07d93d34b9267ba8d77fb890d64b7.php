<?php if (!defined('THINK_PATH')) exit(); /*a:2:{s:78:"D:\phpStudy\WWW\lesson\tp5\public/../application/index\view\manager\index.html";i:1525507020;s:71:"D:\phpStudy\WWW\lesson\tp5\public/../application/index\view\layout.html";i:1525596205;}*/ ?>
<!doctype html>
<html lang="cn" class="fullscreen-bg">

<head>
    <title>考研狗之家后台管理登录页面</title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">

    <link rel="stylesheet" href="/assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="/assets/vendor/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="/assets/vendor/linearicons/style.css">
    
    <link rel="stylesheet" href="/assets/css/main.css">
    
    <link rel="stylesheet" href="/assets/css/demo.css">
    
    <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700" rel="stylesheet">
    
    <link rel="apple-touch-icon" sizes="76x76" href="/assets/img/apple-icon.png">
    <link rel="icon" type="image/png" sizes="96x96" href="/assets/img/favicon.png">
</head>

<body>
    
    <div id="wrapper">
        
        <div class="vertical-align-wrap">
            <div class="vertical-align-middle">
                <div class="auth-box ">
                    <div class="left">
                        <div class="content">
                            <div class="header">
                                <div class="logo text-center"><img src="assets/img/logo-dark.png" alt="Klorofil Logo"></div>
                                <p class="lead">管理员登录</p>
                            </div>
                            <form class="form-auth-small" action="/index/manager/dologin" method="post">
                                <div class="form-group">
                                    <label for="signin-email" class="control-label sr-only">username</label>
                                    <input type="text" class="form-control" id="admin"  placeholder="username" name="username">
                                </div>
                                <div class="form-group">
                                    <label for="signin-password" class="control-label sr-only">password</label>
                                    <input type="password" class="form-control" id="password"  placeholder="password" name="password">
                                </div>
                                <div class="form-group clearfix">
                                    <label class="fancy-checkbox element-left">
                                        <input type="checkbox">
                                        <span>记住密码</span>
                                    </label>
                                </div>
                                <input type="submit" class="btn btn-primary btn-lg btn-block" value="登录"></input>
                            </form>
                        </div>
                    </div>
                    <div class="right">
                        <div class="overlay"></div>
                        <div class="content text">
                            <h1 class="heading">“考研狗之家”后台管理系统登录页面</h1>
                            <p>在这里 寻找梦想起飞的秘密</p>
                        </div>
                    </div>
                    <div class="clearfix"></div>
                </div>
            </div>
        </div>

     </div>

</body>

</html>