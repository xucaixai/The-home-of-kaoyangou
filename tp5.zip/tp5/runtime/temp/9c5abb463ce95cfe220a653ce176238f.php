<?php if (!defined('THINK_PATH')) exit(); /*a:2:{s:77:"D:\phpStudy\WWW\lesson\tp5\public/../application/front\view\index\author.html";i:1525242407;s:71:"D:\phpStudy\WWW\lesson\tp5\public/../application/front\view\layout.html";i:1525852649;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="favicon.ico">
    <title>Renda - clean blog theme based on Bootstrap</title>
    <!-- Bootstrap core CSS -->
    <link href="/static/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
    <!-- Custom styles for this template -->
    <link href="/static/css/jquery.bxslider.css" rel="stylesheet">
    <link href="/static/css/style.css" rel="stylesheet">
</head>
<body>
<!-- Navigation -->
<nav class="navbar navbar-inverse navbar-fixed-top">
    <div class="container">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
        </div>
        <div id="navbar" class="collapse navbar-collapse">
            <ul class="nav navbar-nav">
                <li class="active"><a href="/front/index">首页</a></li>
                <li><a href="#about">热门文章</a></li>
                <li><a href="/front/infor/school">院校预览</a></li>
                <li><a href="/front/infor/major">资料下载</a></li>
                <ul class="nav navbar-nav navbar-right">
                    <?php if(empty(\think\Session::get('loginedUser')) || ((\think\Session::get('loginedUser') instanceof \think\Collection || \think\Session::get('loginedUser') instanceof \think\Paginator ) && \think\Session::get('loginedUser')->isEmpty())): ?>
                    <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
                                登录/注册
                            <span class="caret"></span></a>
                        <ul class="dropdown-menu">
                            <li><a href="/front/user/login">登录</a></li>
                            <li role="separator" class="divider"></li>
                            <li><a href="/front/user/register">注册</a></li>
                        </ul>
                    </li>
                    <?php else: ?>
                    <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
                                <?php echo \think\Session::get('loginedUser'); ?>
                            <span class="caret"></span></a>
                        <ul class="dropdown-menu">
                            <li><a href="/front/user/index">个人中心</a></li>
                            <li role="separator" class="divider"></li>
                            <li><a href="/front/article/index">编辑</a></li>
                            <li role="separator" class="divider"></li>
                            <li><a href="/front/user/logout">注销</a></li>
                        </ul>
                    </li>
                    <?php endif; ?>
                </ul>
            </ul>

            <ul class="nav navbar-nav navbar-right">
                <li><a href="#"><i class="fa fa-weibo"></i></a></li>
                <li><a href="#"><i class="fa fa-qq"></i></a></li>
                <li><a href="#"><i class="fa fa-weixin"></i></a></li>
                <li><a href="http://www.google.com"><i class="fa fa-google-plus"></i></a></li>
                <li><a href="#"><i class="fa fa-dribbble"></i></a></li>
                <li><a href="#"><i class="fa fa-facebook"></i></a></li>
            </ul>

        </div>
        <!--/.nav-collapse -->
    </div>
</nav>

<div class="container">
    <div class="container">
    <header>
        <a href="index.html"><img src="/static/images/logo.png"></a>
    </header>
    <section>
        <div class="row">
            <div class="col-md-12">
                <article class="blog-post">
                    <div class="blog-post-body">
                        <h2><a href="post.html">作者详情介绍</a></h2>
                        <div class="blog-post-text">

                            <p>A newly-developed mathematical method can detect geometric structure in neural activity in the brain. “Previously, in order to understand this structure, scientists needed to relate neural activity to some specific external stimulus,” said Vladimir Itskov, associate professor of mathematics at Penn State University. “Our method is the first to be able to reveal this structure without our knowing an external stimulus ahead of time. We’ve now shown that our new method will allow us to explore the organizational structure of neurons without knowing their function in advance.”</p>

                            <p>“The traditional methods used by researchers to analyze the relationship between the activities of neurons were adopted from physics,” said Carina Curto, associate professor of mathematics at Penn State, “but neuroscience data doesn’t necessarily play by the same rules as data from physics, so we need new tools. Our method is a first step toward developing a new mathematical toolkit to uncover the structure of neural circuits with unknown function in the brain.”</p>

                            <h3>Math reveals structure in neural activity in the brain</h3>
                            <p>The method — clique topology — was developed by an interdisciplinary team of researchers at Penn State, the University of Pennsylvania, the Howard Hughes Medical Institute, and the University of Nebraska-Lincoln. The method is described in a paper that will be posted in the early online edition of the journal Proceedings of the National Academy of Sciences during the week ending October 23, 2015.</p>

                            <p>“We have adopted approaches from the field of algebraic topology that previously had been used primarily in the domain of pure mathematics and have applied them to experimental data on the activity of place cells — specialized neurons in the part of the brain called the hippocampus that sense the position of an animal in its environment,” said Curto.</p>
                        </div>
                    </div>
                </article>
            </div>
        </div>
    </section>
</div><!-- /.container -->

</div>

<footer class="footer">

    <div class="footer-socials">
        <a href="http://www.facebook.com"><i class="fa fa-facebook"></i></a>
        <a href="http://www.twitter.com"><i class="fa fa-twitter"></i></a>
        <a href="http://instagram.com/"><i class="fa fa-instagram"></i></a>
        <a href="http://www.google.com"><i class="fa fa-google-plus"></i></a>
        <a href="#"><i class="fa fa-dribbble"></i></a>
        <a href="#"><i class="fa fa-reddit"></i></a>
    </div>

    <div class="footer-bottom">
        <i class="fa fa-copyright"></i> Copyright 河北师范大学软件学院-考研狗之家.<br>
    
    </div>
</footer>

<!-- Bootstrap core JavaScript
    ================================================== -->
<!-- Placed at the end of the document so the pages load faster -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<script src="/static/js/bootstrap.min.js"></script>
<script src="/static/js/jquery.bxslider.js"></script>
<script src="/static/js/mooz.scripts.min.js"></script>
</body>
</html>