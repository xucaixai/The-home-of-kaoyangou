<?php if (!defined('THINK_PATH')) exit(); /*a:2:{s:77:"D:\phpStudy\WWW\lesson\tp5\public/../application/front\view\infor\school.html";i:1526345929;s:71:"D:\phpStudy\WWW\lesson\tp5\public/../application/front\view\layout.html";i:1525852649;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="favicon.ico">
    <title>Renda - clean blog theme based on Bootstrap</title>
    <!-- Bootstrap core CSS -->
    <link href="/static/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
    <!-- Custom styles for this template -->
    <link href="/static/css/jquery.bxslider.css" rel="stylesheet">
    <link href="/static/css/style.css" rel="stylesheet">
</head>
<body>
<!-- Navigation -->
<nav class="navbar navbar-inverse navbar-fixed-top">
    <div class="container">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
        </div>
        <div id="navbar" class="collapse navbar-collapse">
            <ul class="nav navbar-nav">
                <li class="active"><a href="/front/index">首页</a></li>
                <li><a href="#about">热门文章</a></li>
                <li><a href="/front/infor/school">院校预览</a></li>
                <li><a href="/front/infor/major">资料下载</a></li>
                <ul class="nav navbar-nav navbar-right">
                    <?php if(empty(\think\Session::get('loginedUser')) || ((\think\Session::get('loginedUser') instanceof \think\Collection || \think\Session::get('loginedUser') instanceof \think\Paginator ) && \think\Session::get('loginedUser')->isEmpty())): ?>
                    <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
                                登录/注册
                            <span class="caret"></span></a>
                        <ul class="dropdown-menu">
                            <li><a href="/front/user/login">登录</a></li>
                            <li role="separator" class="divider"></li>
                            <li><a href="/front/user/register">注册</a></li>
                        </ul>
                    </li>
                    <?php else: ?>
                    <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
                                <?php echo \think\Session::get('loginedUser'); ?>
                            <span class="caret"></span></a>
                        <ul class="dropdown-menu">
                            <li><a href="/front/user/index">个人中心</a></li>
                            <li role="separator" class="divider"></li>
                            <li><a href="/front/article/index">编辑</a></li>
                            <li role="separator" class="divider"></li>
                            <li><a href="/front/user/logout">注销</a></li>
                        </ul>
                    </li>
                    <?php endif; ?>
                </ul>
            </ul>

            <ul class="nav navbar-nav navbar-right">
                <li><a href="#"><i class="fa fa-weibo"></i></a></li>
                <li><a href="#"><i class="fa fa-qq"></i></a></li>
                <li><a href="#"><i class="fa fa-weixin"></i></a></li>
                <li><a href="http://www.google.com"><i class="fa fa-google-plus"></i></a></li>
                <li><a href="#"><i class="fa fa-dribbble"></i></a></li>
                <li><a href="#"><i class="fa fa-facebook"></i></a></li>
            </ul>

        </div>
        <!--/.nav-collapse -->
    </div>
</nav>

<div class="container">
    <div  class="container">
<div class="container-fluid">
        <div class="row-fluid">
            <div class="col-lg-12">
                    <p>hello</p>
                    <p>hello</p>
                <ul class="nav nav-tabs">
                        <li >
                                <a href="/front/index/">首页</a>
                            </li>
                            <li class="active">
                                    <a href="/front/infor/school">信息</a>
                                </li>
                            <li>
                                <a href="/front/infor/major">资料</a>
                            </li>
                    <li class="dropdown pull-right">
                         <a href="#" data-toggle="dropdown" class="dropdown-toggle">下拉<strong class="caret"></strong></a>
                        <ul class="dropdown-menu">
                            <li>
                                <a href="#">输入查询学校</a>
                            </li>
                            <li>
                                    <form class="form-search">
                                            <input class="input-medium search-query" type="text" /> <button type="submit" class="btn">查找</button>
                                    </form>
                            </li>
                        </ul>
                    </li>
                </ul>
              
                <ul class="list-unstyled"">
                    <li class="col-lg-4">
                        <div class="thumbnail">
                            <img alt="300x200" src="/static/images/s-5.jpg" />
                            <div class="caption">
                                <h3>
                                        <a href="/front/infor/sinfo/">大学名字</a>
                                </h3>
                                <p>
                                        从数据库中获取
                                </p>
                                <p>
                                    <a class="btn btn-primary" href="/front/infor/sinfo/">浏览</a> <a class="btn" href="#">分享</a>
                                </p>
                            </div>
                        </div>
                    </li>
                    <li class="col-lg-4">
                        <div class="thumbnail">
                            <img alt="300x200" src="/static/images/s-6.jpg" />
                            <div class="caption">
                                <h3>

                                      大学名字
                                    </h3>
                                <p>
                                        从数据库中获取
                                </p>
                                <p>
                                    <a class="btn btn-primary" href="#">浏览</a> <a class="btn" href="#">分享</a>
                                </p>
                            </div>
                        </div>
                    </li>
                    <li class="col-lg-4">
                        <div class="thumbnail">
                            <img alt="300x200" src="/static/images/s-7.jpg" />
                            <div class="caption">
                                <h3>

                                大学名字
                                </h3>
                                <p>
                                    从数据库中获取
                                </p>
                                <p>
                                    <a class="btn btn-primary" href="#">浏览</a> <a class="btn" href="#">分享</a>
                                </p>
                            </div>
                        </div>
                    </li>
                </ul>
            
            </div>
            <div class="pagination pagination-centered">
                        <ul class="pagination ">
                            <li>
                                <a href="#">上一页</a>
                            </li>
                            <li>
                                <a href="#">1</a>
                            </li>
                            <li>
                                <a href="#">2</a>
                            </li>
                            <li>
                                <a href="#">3</a>
                            </li>
                            <li>
                                <a href="#">4</a>
                            </li>
                            <li>
                                <a href="#">5</a>
                            </li>
                            <li>
                                <a href="#">下一页</a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
    </div>
</div>

<footer class="footer">

    <div class="footer-socials">
        <a href="http://www.facebook.com"><i class="fa fa-facebook"></i></a>
        <a href="http://www.twitter.com"><i class="fa fa-twitter"></i></a>
        <a href="http://instagram.com/"><i class="fa fa-instagram"></i></a>
        <a href="http://www.google.com"><i class="fa fa-google-plus"></i></a>
        <a href="#"><i class="fa fa-dribbble"></i></a>
        <a href="#"><i class="fa fa-reddit"></i></a>
    </div>

    <div class="footer-bottom">
        <i class="fa fa-copyright"></i> Copyright 河北师范大学软件学院-考研狗之家.<br>
    
    </div>
</footer>

<!-- Bootstrap core JavaScript
    ================================================== -->
<!-- Placed at the end of the document so the pages load faster -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<script src="/static/js/bootstrap.min.js"></script>
<script src="/static/js/jquery.bxslider.js"></script>
<script src="/static/js/mooz.scripts.min.js"></script>
</body>
</html>