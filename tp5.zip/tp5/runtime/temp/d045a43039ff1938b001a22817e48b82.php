<?php if (!defined('THINK_PATH')) exit(); /*a:2:{s:68:"D:\phpStudy\WWW\tp5\public/../application/admin\view\tag\create.html";i:1513217689;s:64:"D:\phpStudy\WWW\tp5\public/../application/admin\view\layout.html";i:1513212604;}*/ ?>
<!DOCTYPE html>
<html lang="zh-CN">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>软件/硬件产品内容发布与产品服务系统</title>
    <link href="/static/css/bootstrap.min.css" rel="stylesheet">


    <link href="/static/css/common.css" rel="stylesheet">
    <link href="/static/css/main.css" rel="stylesheet">


    <script src="https://cdn.bootcss.com/jquery/3.2.1/jquery.min.js"></script>
    <script src="http://source.wywwwxm.com/js/ajdata.js"></script>
</head>

<body>

<nav class="navbar navbar-default">
    <div class="container-fluid">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand" href="#">Brand</a>
        </div>
        <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
            <ul class="nav navbar-nav">
                <li>
                    <a href="/admin">
                        后台首页
                    </a>
                </li>
            </ul>
            <ul class="nav navbar-nav navbar-right">
                <li class="dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
                        <?php echo \think\Session::get('loginedAdmin'); ?>
                        <span class="caret"></span>
                    </a>
                    <ul class="dropdown-menu">
                        <li><a href="/index">注销</a></li>
                    </ul>
                </li>
            </ul>
        </div>
    </div>
</nav>

<script src="https://cdn.bootcss.com/jquery/1.12.4/jquery.min.js"></script>
<script src="/static/js/bootstrap.min.js"></script>

    <div class="clearfix">
        <div class="sidebar-wrap">
            <div class="sidebar-title">
                <h1>菜单</h1>
            </div>
            <div class="sidebar-content">
                <ul class="sidebar-list">
                    <li>
                        <a href="#"><i class="icon-font">&#xe003;</i>自定义菜单</a>
                        <ul class="sub-menu">
                            <li><a href="/admin/menu"><i class="icon-font">&#xe008;</i>菜单列表</a></li>
                            <li><a href="/admin/menu/create"><i class="icon-font">&#xe008;</i>创建菜单</a></li>
                        </ul>
                    </li>
                    <li>
                        <a href="#"><i class="icon-font">&#xe018;</i>素材管理</a>
                        <ul class="sub-menu">
                            <li><a href="/admin/material"><i class="icon-font">&#xe017;</i>素材列表<li><a href="/admin/material/create"><i class="icon-font">&#xe037;</i>上传素材</a></li>
                        </ul>
                    </li>
                    <li>
                        <a href="#"><i class="icon-font">&#xe018;</i>用户管理</a>
                        <ul class="sub-menu">
                            <li><a href="/admin/wxuser"><i class="icon-font">&#xe017;</i>用户列表<li><a href="/admin/tag"><i class="icon-font">&#xe037;</i>用户标签</a></li>
                        </ul>
                    </li>
                    <li>
                        <a href="#"><i class="icon-font">&#xe018;</i>图文消息</a>
                        <ul class="sub-menu">
                            <li><a href="/admin/news/create"><i class="icon-font">&#xe017;</i>创建图文消息<li><a href="/admin/news"><i class="icon-font">&#xe037;</i>发布图文消息</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>

        <div class="main-wrap">
            <div class="panel panel-default">
    <div class="panel-heading">
        <h3 class="panel-title">创建标签</h3>
    </div>
    <div class="panel-body">
        <form method="post" class="form-group" action="/admin/tag">
            <div>
                <label>内容：</label>
                <textarea class="form-control" rows="21" name="name"></textarea>
            </div>
            <div>
                <br/><br/>
                <div class="col-md-11">
                </div>
                <input type="submit" class="btn btn-success" value="提交">
            </div>
        </form>
    </div>
</div>
        </div>

    </div>
</body>

</html>