<?php if (!defined('THINK_PATH')) exit(); /*a:2:{s:76:"D:\phpStudy\WWW\lesson\tp5\public/../application/front\view\index\index.html";i:1525242628;s:71:"D:\phpStudy\WWW\lesson\tp5\public/../application/front\view\layout.html";i:1525852649;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="favicon.ico">
    <title>Renda - clean blog theme based on Bootstrap</title>
    <!-- Bootstrap core CSS -->
    <link href="/static/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
    <!-- Custom styles for this template -->
    <link href="/static/css/jquery.bxslider.css" rel="stylesheet">
    <link href="/static/css/style.css" rel="stylesheet">
</head>
<body>
<!-- Navigation -->
<nav class="navbar navbar-inverse navbar-fixed-top">
    <div class="container">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
        </div>
        <div id="navbar" class="collapse navbar-collapse">
            <ul class="nav navbar-nav">
                <li class="active"><a href="/front/index">首页</a></li>
                <li><a href="#about">热门文章</a></li>
                <li><a href="/front/infor/school">院校预览</a></li>
                <li><a href="/front/infor/major">资料下载</a></li>
                <ul class="nav navbar-nav navbar-right">
                    <?php if(empty(\think\Session::get('loginedUser')) || ((\think\Session::get('loginedUser') instanceof \think\Collection || \think\Session::get('loginedUser') instanceof \think\Paginator ) && \think\Session::get('loginedUser')->isEmpty())): ?>
                    <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
                                登录/注册
                            <span class="caret"></span></a>
                        <ul class="dropdown-menu">
                            <li><a href="/front/user/login">登录</a></li>
                            <li role="separator" class="divider"></li>
                            <li><a href="/front/user/register">注册</a></li>
                        </ul>
                    </li>
                    <?php else: ?>
                    <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
                                <?php echo \think\Session::get('loginedUser'); ?>
                            <span class="caret"></span></a>
                        <ul class="dropdown-menu">
                            <li><a href="/front/user/index">个人中心</a></li>
                            <li role="separator" class="divider"></li>
                            <li><a href="/front/article/index">编辑</a></li>
                            <li role="separator" class="divider"></li>
                            <li><a href="/front/user/logout">注销</a></li>
                        </ul>
                    </li>
                    <?php endif; ?>
                </ul>
            </ul>

            <ul class="nav navbar-nav navbar-right">
                <li><a href="#"><i class="fa fa-weibo"></i></a></li>
                <li><a href="#"><i class="fa fa-qq"></i></a></li>
                <li><a href="#"><i class="fa fa-weixin"></i></a></li>
                <li><a href="http://www.google.com"><i class="fa fa-google-plus"></i></a></li>
                <li><a href="#"><i class="fa fa-dribbble"></i></a></li>
                <li><a href="#"><i class="fa fa-facebook"></i></a></li>
            </ul>

        </div>
        <!--/.nav-collapse -->
    </div>
</nav>

<div class="container">
    <div class="container-a">
    <header>
        <a href="index.html"><img src="/static/images/logo.png"></a>
    </header>
    <section>
        <div class="row">
            <div class="col-md-8">
                <article class="blog-post">
                    <div class="blog-post-image">
                        <a href="post.html"><img src="/static/images/750x500-1.jpg" alt=""></a>
                    </div>
                    <div class="blog-post-body">
                        <h2><a href="index/news">我的考研之旅</a></h2>
                        <div class="post-meta"><span>by <a href="/index/index/author">Jamie Mooze</a></span>/<span><i class="fa fa-clock-o"></i>March 14, 2015</span>/<span><i class="fa fa-comment-o"></i> <a href="#">343</a></span></div>
                        <p>ew months ago, we found ridiculously cheap plane tickets for Boston and off we went. It was our first visit to the city and, believe it or not, Stockholm in February was more pleasant than Boston in March. It probably has a lot to do with the fact that we arrived completely unprepared. That I, in my converse and thin jacket, did not end up with pneumonia is honestly not even fair.</p>
                        <div class="read-more"><a href="#">Continue Reading</a></div>
                    </div>
                </article>
                <!-- article -->
                <article class="blog-post">
                    <div class="blog-post-image">
                        <a href="post.html"><img src="/static/images/750x500-2.jpg" alt=""></a>
                    </div>
                    <div class="blog-post-body">
                        <h2><a href="post.html">“研路”</a></h2>
                        <div class="post-meta"><span>by <a href="#">Jamie Mooze</a></span>/<span><i class="fa fa-clock-o"></i>March 14, 2015</span>/<span><i class="fa fa-comment-o"></i> <a href="#">343</a></span></div>
                        <p>Few months ago, we found ridiculously cheap plane tickets for Boston and off we went. It was our first visit to the city and, believe it or not, Stockholm in February was more pleasant than Boston in March. It probably has a lot to do with the fact that we arrived completely unprepared.</p>
                        <div class="read-more"><a href="#">Continue Reading</a></div>
                    </div>
                </article>
                <!-- article -->
                <article class="blog-post">
                    <div class="blog-post-image">
                        <a href="post.html"><img src="/static/images/750x500-3.jpg" alt=""></a>
                    </div>
                    <div class="blog-post-body">
                        <h2><a href="post.html">筑梦之旅--我的大学</a></h2>
                        <div class="post-meta"><span>by <a href="#">Jamie Mooze</a></span>/<span><i class="fa fa-clock-o"></i>March 14, 2015</span>/<span><i class="fa fa-comment-o"></i> <a href="#">343</a></span></div>
                        <p>It was our first visit to the city and, believe it or not, Stockholm in February was more pleasant than Boston in March. It probably has a lot to do with the fact that we arrived completely unprepared. Few months ago, we found ridiculously cheap plane tickets for Boston and off we went.</p>
                        <div class="read-more"><a href="#">Continue Reading</a></div>
                    </div>
                </article>
            </div>
            <div class="copyrights">Collect from <a href="http://www.cssmoban.com/" >手机网站模板</a></div>
            <div class="col-md-4 sidebar-gutter">
                <aside>
                    <!-- sidebar-widget -->
                    <div class="sidebar-widget">
                        <h3 class="sidebar-title">About Me</h3>
                        <div class="widget-container widget-about">
                            <a href="post.html"><img src="images/author.jpg" alt=""></a>
                            <h4>Jamie Mooz</h4>
                            <div class="author-title">Designer</div>
                            <p>While everyone’s eyes are glued to the runway, it’s hard to ignore that there are major fashion moments on the front row too.</p>
                        </div>
                    </div>
                    <!-- sidebar-widget -->
                    <div class="sidebar-widget">
                        <h3 class="sidebar-title">Featured Posts</h3>
                        <div class="widget-container">
                            <article class="widget-post">
                                <div class="post-image">
                                    <a href="post.html"><img src="images/90x60-1.jpg" alt=""></a>
                                </div>
                                <div class="post-body">
                                    <h2><a href="post.html">The State of the Word 2014</a></h2>
                                    <div class="post-meta">
                                        <span><i class="fa fa-clock-o"></i> 2. august 2015</span> <span><a href="post.html"><i class="fa fa-comment-o"></i> 23</a></span>
                                    </div>
                                </div>
                            </article>
                            <article class="widget-post">
                                <div class="post-image">
                                    <a href="post.html"><img src="images/90x60-2.jpg" alt=""></a>
                                </div>
                                <div class="post-body">
                                    <h2><a href="post.html">Why The Muppets Needs to Channel 30 Rock</a></h2>
                                    <div class="post-meta">
                                        <span><i class="fa fa-clock-o"></i> 2. august 2015</span> <span><a href="post.html"><i class="fa fa-comment-o"></i> 23</a></span>
                                    </div>
                                </div>
                            </article>
                            <article class="widget-post">
                                <div class="post-image">
                                    <a href="post.html"><img src="images/90x60-3.jpg" alt=""></a>
                                </div>
                                <div class="post-body">
                                    <h2><a href="post.html">The State of the Word 2014</a></h2>
                                    <div class="post-meta">
                                        <span><i class="fa fa-clock-o"></i> 2. august 2015</span> <span><a href="post.html"><i class="fa fa-comment-o"></i> 23</a></span>
                                    </div>
                                </div>
                            </article>
                            <article class="widget-post">
                                <div class="post-image">
                                    <a href="post.html"><img src="images/90x60-4.jpg" alt=""></a>
                                </div>
                                <div class="post-body">
                                    <h2><a href="post.html">Vintage-Inspired Finds for Your Home</a></h2>
                                    <div class="post-meta">
                                        <span><i class="fa fa-clock-o"></i> 2. august 2015</span> <span><a href="post.html"><i class="fa fa-comment-o"></i> 23</a></span>
                                    </div>
                                </div>
                            </article>
                            <article class="widget-post">
                                <div class="post-image">
                                    <a href="post.html"><img src="images/90x60-5.jpg" alt=""></a>
                                </div>
                                <div class="post-body">
                                    <h2><a href="post.html">The State of the Word 2014</a></h2>
                                    <div class="post-meta">
                                        <span><i class="fa fa-clock-o"></i> 2. august 2015</span> <span><a href="post.html"><i class="fa fa-comment-o"></i> 23</a></span>
                                    </div>
                                </div>
                            </article>
                        </div>
                    </div>
                    <!-- sidebar-widget -->
                    <div class="sidebar-widget">
                        <h3 class="sidebar-title">Socials</h3>
                        <div class="widget-container">
                            <div class="widget-socials">
                                <a href="#"><i class="fa fa-facebook"></i></a>
                                <a href="#"><i class="fa fa-twitter"></i></a>
                                <a href="#"><i class="fa fa-instagram"></i></a>
                                <a href="#"><i class="fa fa-google-plus"></i></a>
                                <a href="#"><i class="fa fa-dribbble"></i></a>
                                <a href="#"><i class="fa fa-reddit"></i></a>
                            </div>
                        </div>
                    </div>
                    <!-- sidebar-widget -->
                    <div class="sidebar-widget">
                        <h3 class="sidebar-title">Categories</h3>
                        <div class="widget-container">
                            <ul>
                                <li><a href="#">Fashion</a></li>
                                <li><a href="#">Art</a></li>
                                <li><a href="#">Design</a></li>
                                <li><a href="#">Featured</a></li>
                                <li><a href="#">Graphics</a></li>
                                <li><a href="#">Peoples</a></li>
                                <li><a href="#">Uncategorized</a></li>
                            </ul>
                        </div>
                    </div>
                </aside>
            </div>

        </div>
    </section>
</div><!-- /.container -->
</div>

<footer class="footer">

    <div class="footer-socials">
        <a href="http://www.facebook.com"><i class="fa fa-facebook"></i></a>
        <a href="http://www.twitter.com"><i class="fa fa-twitter"></i></a>
        <a href="http://instagram.com/"><i class="fa fa-instagram"></i></a>
        <a href="http://www.google.com"><i class="fa fa-google-plus"></i></a>
        <a href="#"><i class="fa fa-dribbble"></i></a>
        <a href="#"><i class="fa fa-reddit"></i></a>
    </div>

    <div class="footer-bottom">
        <i class="fa fa-copyright"></i> Copyright 河北师范大学软件学院-考研狗之家.<br>
    
    </div>
</footer>

<!-- Bootstrap core JavaScript
    ================================================== -->
<!-- Placed at the end of the document so the pages load faster -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<script src="/static/js/bootstrap.min.js"></script>
<script src="/static/js/jquery.bxslider.js"></script>
<script src="/static/js/mooz.scripts.min.js"></script>
</body>
</html>