<?php if (!defined('THINK_PATH')) exit(); /*a:2:{s:76:"D:\phpStudy\WWW\lesson\tp5\public/../application/front\view\infor\sinfo.html";i:1526344530;s:71:"D:\phpStudy\WWW\lesson\tp5\public/../application/front\view\layout.html";i:1525852649;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="favicon.ico">
    <title>Renda - clean blog theme based on Bootstrap</title>
    <!-- Bootstrap core CSS -->
    <link href="/static/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
    <!-- Custom styles for this template -->
    <link href="/static/css/jquery.bxslider.css" rel="stylesheet">
    <link href="/static/css/style.css" rel="stylesheet">
</head>
<body>
<!-- Navigation -->
<nav class="navbar navbar-inverse navbar-fixed-top">
    <div class="container">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
        </div>
        <div id="navbar" class="collapse navbar-collapse">
            <ul class="nav navbar-nav">
                <li class="active"><a href="/front/index">首页</a></li>
                <li><a href="#about">热门文章</a></li>
                <li><a href="/front/infor/school">院校预览</a></li>
                <li><a href="/front/infor/major">资料下载</a></li>
                <ul class="nav navbar-nav navbar-right">
                    <?php if(empty(\think\Session::get('loginedUser')) || ((\think\Session::get('loginedUser') instanceof \think\Collection || \think\Session::get('loginedUser') instanceof \think\Paginator ) && \think\Session::get('loginedUser')->isEmpty())): ?>
                    <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
                                登录/注册
                            <span class="caret"></span></a>
                        <ul class="dropdown-menu">
                            <li><a href="/front/user/login">登录</a></li>
                            <li role="separator" class="divider"></li>
                            <li><a href="/front/user/register">注册</a></li>
                        </ul>
                    </li>
                    <?php else: ?>
                    <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
                                <?php echo \think\Session::get('loginedUser'); ?>
                            <span class="caret"></span></a>
                        <ul class="dropdown-menu">
                            <li><a href="/front/user/index">个人中心</a></li>
                            <li role="separator" class="divider"></li>
                            <li><a href="/front/article/index">编辑</a></li>
                            <li role="separator" class="divider"></li>
                            <li><a href="/front/user/logout">注销</a></li>
                        </ul>
                    </li>
                    <?php endif; ?>
                </ul>
            </ul>

            <ul class="nav navbar-nav navbar-right">
                <li><a href="#"><i class="fa fa-weibo"></i></a></li>
                <li><a href="#"><i class="fa fa-qq"></i></a></li>
                <li><a href="#"><i class="fa fa-weixin"></i></a></li>
                <li><a href="http://www.google.com"><i class="fa fa-google-plus"></i></a></li>
                <li><a href="#"><i class="fa fa-dribbble"></i></a></li>
                <li><a href="#"><i class="fa fa-facebook"></i></a></li>
            </ul>

        </div>
        <!--/.nav-collapse -->
    </div>
</nav>

<div class="container">
    
<div class="container">
        <div class="row-fluid">
            <p>hello</p>
            <p>hello</p>
            <div class="span12">
                <h3 class="text-center">
                    <a href="#">XX大学</a>
                </h3>
                <dl>
                    <dt>
                        Rolex
                    </dt>
                    <dd>
                            清华大学（Tsinghua University），简称“清华”，由中华人民共和国教育部直属，中央直管副部级建制，位列“211工程”、“985工程”、“世界一流大学和一流学科”，入选“基础学科拔尖学生培养试验计划”、“高等学校创新能力提升计划”、“高等学校学科创新引智计划”，为九校联盟、中国大学校长联谊会、东亚研究型大学协会、亚洲大学联盟、环太平洋大学联盟、清华—剑桥—MIT低碳大学联盟成员，被誉为“红色工程师的摇篮”。
                    
                    </dd>
                    <dt>
                        Vacheron Constantin
                    </dt>
                    <dd>
                            清华大学的前身清华学堂始建于1911年，因水木清华而得名，是清政府设立的留美预备学校，其建校的资金源于1908年美国退还的部分庚子赔款。1912年更名为清华学校。1928年更名为国立清华大学。1937年抗日战争全面爆发后南迁长沙，与北京大学、南开大学组建国立长沙临时大学，1938年迁至昆明改名为国立西南联合大学。1946年迁回清华园。1949年中华人民共和国成立，清华大学进入了新的发展阶段。1952年全国高等学校院系调整后成为多科性工业大学。1978年以来逐步恢复和发展为综合性的研究型大学。
                            
                    </dd>
                    <dd>
                            水木清华，钟灵毓秀，清华大学秉持“自强不息、厚德载物”的校训和“行胜于言”的校风，坚持“中西融汇、古今贯通、文理渗透”的办学风格和“又红又专、全面发展”的培养特色，弘扬“爱国奉献、追求卓越”传统和“人文日新”精神。恰如清华园工字厅内对联所书——“槛外山光，历春夏秋冬、万千变幻，都非凡境；窗中云影，任东西南北、去来澹荡，洵是仙居”。 [1] 
                    </dd>
                    <dt>
                        IWC
                    </dt>
                    <dd>
                            水木清华，钟灵毓秀，清华大学秉持“自强不息、厚德载物”的校训和“行胜于言”的校风，坚持“中西融汇、古今贯通、文理渗透”的办学风格和“又红又专、全面发展”的培养特色，弘扬“爱国奉献、追求卓越”传统和“人文日新”精神。恰如清华园工字厅内对联所书——“槛外山光，历春夏秋冬、万千变幻，都非凡境；窗中云影，任东西南北、去来澹荡，洵是仙居”。 [1] 
                    </dd>
                    <dt>
                       招生简章
                    </dt>
                    <dd>
                       <a href="#">从数据库中获取</a>
                    </dd>
                </dl>
            </div>
        </div>
    </div>
</div>

<footer class="footer">

    <div class="footer-socials">
        <a href="http://www.facebook.com"><i class="fa fa-facebook"></i></a>
        <a href="http://www.twitter.com"><i class="fa fa-twitter"></i></a>
        <a href="http://instagram.com/"><i class="fa fa-instagram"></i></a>
        <a href="http://www.google.com"><i class="fa fa-google-plus"></i></a>
        <a href="#"><i class="fa fa-dribbble"></i></a>
        <a href="#"><i class="fa fa-reddit"></i></a>
    </div>

    <div class="footer-bottom">
        <i class="fa fa-copyright"></i> Copyright 河北师范大学软件学院-考研狗之家.<br>
    
    </div>
</footer>

<!-- Bootstrap core JavaScript
    ================================================== -->
<!-- Placed at the end of the document so the pages load faster -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<script src="/static/js/bootstrap.min.js"></script>
<script src="/static/js/jquery.bxslider.js"></script>
<script src="/static/js/mooz.scripts.min.js"></script>
</body>
</html>